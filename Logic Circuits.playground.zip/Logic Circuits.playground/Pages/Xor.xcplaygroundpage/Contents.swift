//: # Xor: The Exclusive Or
//:
//: Xor is Or, but with an extra step.
//:
//: If one of its inputs is powered, the Xor gate will output high; but if **all** inputs are powered, it shuts off.
//:
//: Run the live view to see two equivalent logic sequences, of the Xor's actual logic, and a component I designed for it.
//:
//: Graphically it appears as a half moon with a closing parenthesis.
//:
//: This is the last of the basic components. Now, let's [take a look at a larger circuit](@next).
//:

import PlaygroundSupport
import SwiftUI

let layout: [Component] = [
    Component(id: UUID(uuidString: "593AE554-A557-4D40-BE40-1E8E8F371537")!, name: "Xor logic 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "C038DB4F-3831-4FE4-BF3E-04C428669A79")!, node: 0), GateXput(id: UUID(uuidString: "BFDDED62-CA4C-4AAF-BD31-CFCA668685F9")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "476B4FDC-DD78-4581-96F2-3C8286CE9C25")!, name: "Xor logic 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "C038DB4F-3831-4FE4-BF3E-04C428669A79")!, node: 1), GateXput(id: UUID(uuidString: "BFDDED62-CA4C-4AAF-BD31-CFCA668685F9")!, node: 1)]], .input),
    Component(id: UUID(uuidString: "CCDB3C6E-2E15-43B1-95CB-C2833BB26C2A")!, name: "Xor gate 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "B3C27954-B2CA-4896-940E-847D4DC4120D")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "2CB477F9-6C9A-4FFB-81C9-4F80A4536DF2")!, name: "Xor gate 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "B3C27954-B2CA-4896-940E-847D4DC4120D")!, node: 1)]], .input),
    Component(id: UUID(uuidString: "86023B21-0B9E-442F-98A2-E384623343D3")!, name: "Xor logic", state: false, outputs: [], .output),
    Component(id: UUID(uuidString: "E11F0FF3-7299-4640-A0DC-AB0104A862C3")!, name: "Xor gate", state: false, outputs: [], .output),
    Component(id: UUID(uuidString: "B3C27954-B2CA-4896-940E-847D4DC4120D")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "E11F0FF3-7299-4640-A0DC-AB0104A862C3")!, node: 0)]], .xor2),
    Component(id: UUID(uuidString: "BFDDED62-CA4C-4AAF-BD31-CFCA668685F9")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "C62835F3-59B4-4425-910A-F7DA102BA7BF")!, node: 0)]], .or2),
    Component(id: UUID(uuidString: "C62835F3-59B4-4425-910A-F7DA102BA7BF")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "86023B21-0B9E-442F-98A2-E384623343D3")!, node: 0)]], .and2),
    Component(id: UUID(uuidString: "C038DB4F-3831-4FE4-BF3E-04C428669A79")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "D2854472-5709-46C8-AEBE-6D17C8009F0E")!, node: 0)]], .and2),
    Component(id: UUID(uuidString: "D2854472-5709-46C8-AEBE-6D17C8009F0E")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "C62835F3-59B4-4425-910A-F7DA102BA7BF")!, node: 1)]], .not)
]

let pad = Pad(
    gates: [],
    layout: layout,
    positions: [
        UUID(uuidString: "2CB477F9-6C9A-4FFB-81C9-4F80A4536DF2")!: Coord2D(25, 300),
        UUID(uuidString: "86023B21-0B9E-442F-98A2-E384623343D3")!: Coord2D(575, 70),
        UUID(uuidString: "B3C27954-B2CA-4896-940E-847D4DC4120D")!: Coord2D(200, 260),
        UUID(uuidString: "C62835F3-59B4-4425-910A-F7DA102BA7BF")!: Coord2D(459, 74),
        UUID(uuidString: "C038DB4F-3831-4FE4-BF3E-04C428669A79")!: Coord2D(200, 120),
        UUID(uuidString: "CCDB3C6E-2E15-43B1-95CB-C2833BB26C2A")!: Coord2D(25, 206),
        UUID(uuidString: "E11F0FF3-7299-4640-A0DC-AB0104A862C3")!: Coord2D(350, 260),
        UUID(uuidString: "593AE554-A557-4D40-BE40-1E8E8F371537")!: Coord2D(25, 25),
        UUID(uuidString: "476B4FDC-DD78-4581-96F2-3C8286CE9C25")!: Coord2D(25, 120),
        UUID(uuidString: "BFDDED62-CA4C-4AAF-BD31-CFCA668685F9")!: Coord2D(200, 25),
        UUID(uuidString: "D2854472-5709-46C8-AEBE-6D17C8009F0E")!: Coord2D(322, 120)]
)


PlaygroundPage.current.setLiveView(pad.frame(width: 700, height: 400))
