//: # Logic Circuits
//: Hello and welcome to my submission to the 2021 Swift challenge.
//:
//: This Playground is for the demonstration of boolean logic gates.
//: As well as providing information on how each one functions, this project also comes with a live view where you can string them together to prototype any circuit.
//:
//: I'll start by introducing the basic components and showing you how to use the live view. Then, we'll take a look at a larger circuit I developed using this playground.
//:
//: ### Two types of components
//: - *Logic Gates* are the classic components which perform simple boolean logic to produce a result value from one or more inputs. Implemented here are **Not**, **Exclusive Or**, and variations of **Or** and **And** for two or three inputs.
//:
//: Fixed In/Outputs do not perform logic as such.
//: - *Fixed Inputs* allow you to send in static boolean values through your logic sequences. Their state is controlled exclusively by user interaction and cannot be controlled by the circuit itself.
//: - *Fixed Outputs* can be connected to another gate's output to better illustrate its state. Their state is controlled exclusively by the circuit and accepts no user interaction.
//:
//: ### The live view
//: - Note: I'll explain what all the gates do over the following pages so don't worry about what the different symbols on the live view mean yet.
//: - *Logic Gates* appear as their symbol with connecting circles/triangles to the right and left.
//: - *Fixed Inputs* appear as a small dot surrounded by a ring, rather like a target, **with a circle to the right**. Toggle one by double clicking on the target.
//: - *Fixed Outputs* also appear as a target, with a **triangle** to the **left**.
//:
//: #### Connecting components
//: Gate input points are represented as small triangles. Gate output points are represented as small circles. So, to connect two gates, click on a circle and a triangle.

//: [Begin](@next)

import PlaygroundSupport
import SwiftUI

let layout = [
    Component(id: UUID(uuidString: "067050DE-2ECD-4CE4-8D8E-BE83A1DCCD74")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "9567F7FC-40C0-4ED9-895F-9BAE92E88044")!, node: 0)]], .not),
    Component(id: UUID(uuidString: "9D311087-BB76-48F2-ABBF-21371F606526")!, state: false, outputs: [[]], .and2),
    Component(id: UUID(uuidString: "6966915C-C08D-4BD4-BA94-85BB0044708B")!, state: false, outputs: [[]], .and3),
    Component(id: UUID(uuidString: "7B7338C5-7394-4FE4-923D-2C8290755A40")!, state: false, outputs: [[]], .or2),
    Component(id: UUID(uuidString: "091804F3-3F4C-41A8-84BB-9E874B5D08CA")!, state: false, outputs: [[]], .or3),
    Component(id: UUID(uuidString: "1EAE2BF5-278E-4763-BC13-712527AFCE6F")!, state: false, outputs: [[]], .xor2),
    Component(id: UUID(uuidString: "333ABC96-455B-4146-BA28-BECFE8AA8D7B")!, name: "Dbl. click me", state: false, outputs: [[GateXput(id: UUID(uuidString: "067050DE-2ECD-4CE4-8D8E-BE83A1DCCD74")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "9567F7FC-40C0-4ED9-895F-9BAE92E88044")!, name: "Don't click me", state: true, outputs: [], .output)
]
let positions = [
    UUID(uuidString: "7B7338C5-7394-4FE4-923D-2C8290755A40")!: Coord2D(380.0, 75.0),
    UUID(uuidString: "333ABC96-455B-4146-BA28-BECFE8AA8D7B")!: Coord2D(80.0, 280.0),
    UUID(uuidString: "9D311087-BB76-48F2-ABBF-21371F606526")!: Coord2D(230.0, 75.0),
    UUID(uuidString: "6966915C-C08D-4BD4-BA94-85BB0044708B")!: Coord2D(230.0, 180.0),
    UUID(uuidString: "1EAE2BF5-278E-4763-BC13-712527AFCE6F")!: Coord2D(80.0, 180.0),
    UUID(uuidString: "067050DE-2ECD-4CE4-8D8E-BE83A1DCCD74")!: Coord2D(230.0, 280),
    UUID(uuidString: "9567F7FC-40C0-4ED9-895F-9BAE92E88044")!: Coord2D(380.0, 280.0),
    UUID(uuidString: "091804F3-3F4C-41A8-84BB-9E874B5D08CA")!: Coord2D(380.0, 180.0)
]

let pad = Pad(
    gates: [],
    layout: layout,
    positions: positions
)

//: - Callout(Being Fussy):
//: I like to think my **neumorphic styling** works better when contrasted with one of Xcode's dark themes. Could just be me.

PlaygroundPage.current.setLiveView(pad.frame(width: 700, height: 400))
