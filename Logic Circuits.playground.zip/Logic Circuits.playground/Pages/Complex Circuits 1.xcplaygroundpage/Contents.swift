//: ## Complex Ciruits 1
//:
//: Using these simple components, larger and more complex circuits can be developed.
//:
//: Here for example is the **Full Adder** circuit, used in real life ALUs for binary addition.
//:
//: An individual Full Adder circuit computes the sum of two single-digit binary numbers. To work with numbers where the sum can be greater than 1, multiple Full Adder circuits are chained together by connecting the **Co (Carry next)** to the next higher bit's **Ci (Carry from)**
//:
//: I probably don't have enough time to go into details about how this circuit works, so for now just see what happens when you toggle the three inputs.

//: And lastly: [Free play](@next)

import PlaygroundSupport
import SwiftUI


let g1 = UUID(uuidString: "00C75FF0-E87C-4883-9802-905DE42BC6B6")!
let g2 = UUID(uuidString: "4EEE5F88-8B1B-48E1-BF43-4D1C4D296026")!
let g3 = UUID(uuidString: "057463F3-9571-4B6A-B5EA-5E38D13009CE")!
let g4 = UUID(uuidString: "C1D9681E-5735-4EC5-9AB1-3BBF85B51EC7")!
let g5 = UUID(uuidString: "CD7D7113-367C-4315-B268-C553E68098D6")!
let g6 = UUID(uuidString: "6B47E4F8-5A1C-40FD-BD5A-CE3070892C04")!
let g7 = UUID(uuidString: "58A93DC7-8F09-4623-B0C9-91AA8B80DC2B")!
let g8 = UUID(uuidString: "73E43E7B-471B-45E3-BEAA-9D9719E644CE")!
let g9 = UUID(uuidString: "9CF8E209-821C-4EC6-8198-3DCB19C7662B")!
let g10 = UUID(uuidString: "BADB841C-72A6-4FB6-A98C-D64D04E6BFFF")!
let g11 = UUID(uuidString: "B07A9A86-CC3A-4E7A-8D76-4393E5D4BA2A")!
let g12 = UUID(uuidString: "44DD5743-362D-4058-B9DB-FA3516047CFC")!
let g13 = UUID(uuidString: "953FF67B-F32D-4EAB-9A7C-8317802743A4")!

let layout = [
    Component(id: g1, name: "Carry in", state: false, outputs: [[GateXput(id: g2, node: 1), GateXput(id: g3, node: 1), GateXput(id: g4, node: 2), GateXput(id: g5, node: 2)]], .input),
    Component(id: g6, name: "Bit 2", state: false, outputs: [[GateXput(id: g3, node: 0), GateXput(id: g5, node: 1), GateXput(id: g7, node: 1), GateXput(id: g4, node: 1)]], .input),
    Component(id: g8, name: "Bit 1", state: false, outputs: [[GateXput(id: g5, node: 0), GateXput(id: g4, node: 0), GateXput(id: g7, node: 0), GateXput(id: g2, node: 0)]], .input),
    Component(id: g9, name: "Carry out", state: false, outputs: [], .output),
    Component(id: g10, name: "Sum bit", state: false, outputs: [], .output),
    Component(id: g7, state: false, outputs: [[GateXput(id: g11, node: 0)]], .and2),
    Component(id: g2, state: false, outputs: [[GateXput(id: g11, node: 1)]], .and2),
    Component(id: g3, state: false, outputs: [[GateXput(id: g11, node: 2)]], .and2),
    Component(id: g11, state: false, outputs: [[GateXput(id: g12, node: 0), GateXput(id: g9, node: 0)]], .or3),
    Component(id: g4, state: false, outputs: [[GateXput(id: g13, node: 0)]], .or3),
    Component(id: g5, state: false, outputs: [[GateXput(id: g9, node: 0), GateXput(id: g10, node: 0)]], .and3),
    Component(id: g12, state: true, outputs: [[GateXput(id: g13, node: 1)]], .not),
    Component(id: g13, state: false, outputs: [[GateXput(id: g10, node: 0)]], .and2)
]

let pad = Pad(
    gates: [],
    layout: layout,
    positions: [g6: Coord2D(25, 160),
                g2: Coord2D(200, 290),
                g9: Coord2D(675, 70),
                g8: Coord2D(25, 0),
                g5: Coord2D(340, 50),
                g7: Coord2D(200, 180),
                g4: Coord2D(340, 180),
                g1: Coord2D(25, 326),
                g11: Coord2D(340, 390),
                g12: Coord2D(480, 390),
                g10: Coord2D(675, 290),
                g3: Coord2D(200, 390),
                g13: Coord2D(480, 290)]
)

PlaygroundPage.current.setLiveView(pad.frame(width: 800, height: 500))
