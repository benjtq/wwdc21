//:# Finally: The blank page
//:
//: This is a free area to try out the different gates. It provides a demonstration of the full capabilities of my Playground.
//:
//: Not to be overlooked is this page's useful pratical application — an area for experimentation when prototyping a specific circuit.
//:
//: [Complex Circuits 1](@previous)
//:
//: **Reminder: How to use**
//: - Use the bar at the top to add a gate to your circuit
//: - Drag gates around to position them
//: - Double click a fixed input to toggle its state
//: - Click a circle and a triangle to make a connection
//: - Long-press a gate or connection line to remove it
//: - Connection points with multiple connections can obscure the touch target
 
import PlaygroundSupport
import SwiftUI

let pad = Pad(
    gates: .allAndFixed,
    layout: [
        Component(id: UUID(uuidString: "D3883DE7-D0FA-4A01-8802-7116F48C5210")!, name: "An Input", state: false, outputs: [[]], .input),
        Component(id: UUID(uuidString: "1ACD8212-A74B-4182-98F5-0A8854CB19C3")!, name: "An Output", state: false, outputs: [], .output)],
    positions: [
        UUID(uuidString: "D3883DE7-D0FA-4A01-8802-7116F48C5210")!: Coord2D(25, 270),
        UUID(uuidString: "1ACD8212-A74B-4182-98F5-0A8854CB19C3")!: Coord2D(675, 270)]
)

PlaygroundPage.current.setLiveView(pad.frame(width: 800, height: 600))
