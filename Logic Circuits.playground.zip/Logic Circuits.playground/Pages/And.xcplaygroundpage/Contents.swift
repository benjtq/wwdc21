//: # And gates
//:
//: And gates are another important component. An And gate will output a high signal if all of its inputs are powered.
//:
//: The actual logic for an And gate is as simple as inverting input signals and feeding them into an Or gate — then taking the inverse of that.
//:
//: But I did implement a designated And gate also, which is demonstrated in the live view.
//:
//: - Callout(Remember):
//: Double click the input targets
//:
//: The last gate to demonstrate is the [Xor gate](@next)

import PlaygroundSupport
import SwiftUI

// If you unfold these declarations you can see it gets a bit messay
let layout: [Component] = [
    Component(id: UUID(uuidString: "32B1ABE4-ABD5-4351-9687-C124BD19CE77")!, name: "And In 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "2B718DB1-F731-40C6-ADF9-C0550951594A")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "8FE2EC91-8D4B-44C6-AF73-548BC42603C6")!, name: "And In 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "559B9BE8-4CC5-4F34-B2DF-DF419E86E036")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "34954178-C5F0-414D-95C9-01CA8DFC7ED6")!, name: "And Gate Out", state: false, outputs: [], .output),
    Component(id: UUID(uuidString: "DD3D449B-9FE3-49A0-96D9-F6FF2FFA97C5")!, name: "And In 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "C4CF332C-9AD0-4EE3-9370-7C70D09689D5")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "623CBEDC-8A99-4046-B58D-E548E5A9DDAC")!, name: "And In 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "C4CF332C-9AD0-4EE3-9370-7C70D09689D5")!, node: 1)]], .input),
    Component(id: UUID(uuidString: "C4CF332C-9AD0-4EE3-9370-7C70D09689D5")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "34954178-C5F0-414D-95C9-01CA8DFC7ED6")!, node: 0)]], .and2),
    Component(id: UUID(uuidString: "2B718DB1-F731-40C6-ADF9-C0550951594A")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "DEC70240-A08A-4A39-AC57-781EE238DE39")!, node: 1)]], .not),
    Component(id: UUID(uuidString: "559B9BE8-4CC5-4F34-B2DF-DF419E86E036")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "DEC70240-A08A-4A39-AC57-781EE238DE39")!, node: 0)]], .not),
    Component(id: UUID(uuidString: "DEC70240-A08A-4A39-AC57-781EE238DE39")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "520D24E7-60C4-4839-A403-DB8EDB9ED492")!, node: 0)]], .or2),
    Component(id: UUID(uuidString: "520D24E7-60C4-4839-A403-DB8EDB9ED492")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "B230119D-5F8C-4827-8649-A3891CF0233D")!, node: 0)]], .not),
    Component(id: UUID(uuidString: "B230119D-5F8C-4827-8649-A3891CF0233D")!, name: "And logic out", state: false, outputs: [], .output)
]

let pad = Pad(
    gates: [],
    layout: layout,
    positions: [
        UUID(uuidString: "520D24E7-60C4-4839-A403-DB8EDB9ED492")!: Coord2D(450, 65),
        UUID(uuidString: "B230119D-5F8C-4827-8649-A3891CF0233D")!: Coord2D(575, 65),
        UUID(uuidString: "559B9BE8-4CC5-4F34-B2DF-DF419E86E036")!: Coord2D(140, 25),
        UUID(uuidString: "32B1ABE4-ABD5-4351-9687-C124BD19CE77")!: Coord2D(25, 115),
        UUID(uuidString: "34954178-C5F0-414D-95C9-01CA8DFC7ED6")!: Coord2D(275, 250),
        UUID(uuidString: "8FE2EC91-8D4B-44C6-AF73-548BC42603C6")!: Coord2D(25, 25),
        UUID(uuidString: "623CBEDC-8A99-4046-B58D-E548E5A9DDAC")!: Coord2D(25, 295),
        UUID(uuidString: "DD3D449B-9FE3-49A0-96D9-F6FF2FFA97C5")!: Coord2D(25, 205),
        UUID(uuidString: "C4CF332C-9AD0-4EE3-9370-7C70D09689D5")!: Coord2D(160, 250),
        UUID(uuidString: "2B718DB1-F731-40C6-ADF9-C0550951594A")!: Coord2D(140, 116),
        UUID(uuidString: "DEC70240-A08A-4A39-AC57-781EE238DE39")!: Coord2D(300, 65)
    ]
)

PlaygroundPage.current.setLiveView(pad.frame(width: 700, height: 400))
