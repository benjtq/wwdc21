//: # Not & Or gates: The most important
//:
//: Why? Because these two are the building blocks for all of the others.
//:
//:
//: ### Not
//: The Not gate inverts its input signal. This is **the most fundamental boolean logic operation**.
//: Check it out over in the live view: it appears as a triangle pointing into a vertical line. Try changing its input signal (by double clicking on the input target) and observe its output.
//:
//: ### Or
//: The Or gate outputs a high signal if any one of its inputs is powered. I created a designated gate for it as you can see in the live view — it appears as a half moon — but you can actually just merge multiple signals to achieve the same, as demonstrated in the live view.
//:
//: Go to **[And](@next)**
//:

import PlaygroundSupport
import SwiftUI

let layout = [
    Component(id: UUID(uuidString: "1B870A34-5AB0-463B-B349-6FF66184403A")!, name: "Or In 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "30B1B1E2-BBB5-48DB-8268-27587C776B8B")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "32319F0E-9154-41CA-A081-F882DB18171D")!, name: "Or In 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "30B1B1E2-BBB5-48DB-8268-27587C776B8B")!, node: 1)]], .input),
    Component(id: UUID(uuidString: "86095733-67FA-4398-BD93-9C33D02228CE")!, name: "Or merge 1", state: false, outputs: [[GateXput(id: UUID(uuidString: "E8178AD8-D91A-4685-B3A2-8043A9A91148")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "E8178AD8-D91A-4685-B3A2-8043A9A91148")!, name: "Merge Or Out", state: false, outputs: [], .output),
    Component(id: UUID(uuidString: "B719F6D4-1B04-49C7-9106-DE1CB2AE0A76")!, name: "Or Out", state: false, outputs: [], .output),
    Component(id: UUID(uuidString: "018FB050-C899-4D28-9870-07DF953269CA")!, name: "Or merge 2", state: false, outputs: [[GateXput(id: UUID(uuidString: "E8178AD8-D91A-4685-B3A2-8043A9A91148")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "30B1B1E2-BBB5-48DB-8268-27587C776B8B")!, state: false, outputs: [[GateXput(id: UUID(uuidString: "B719F6D4-1B04-49C7-9106-DE1CB2AE0A76")!, node: 0)]], .or2),
    Component(id: UUID(uuidString: "44431ACE-F21E-4797-95B0-A0824830BAD7")!, state: true, outputs: [[GateXput(id: UUID(uuidString: "CCD6CF0C-E5EC-438A-BFE8-8D8F0544EE49")!, node: 0)]], .not),
    Component(id: UUID(uuidString: "DE8AD5B4-F6EC-4E4D-A665-944308173638")!, name: "Not In", state: false, outputs: [[GateXput(id: UUID(uuidString: "44431ACE-F21E-4797-95B0-A0824830BAD7")!, node: 0)]], .input),
    Component(id: UUID(uuidString: "CCD6CF0C-E5EC-438A-BFE8-8D8F0544EE49")!, name: "Not Out", state: true, outputs: [], .output)
]

let pad = Pad(
    gates: [],
    layout: layout,
    positions: [
        UUID(uuidString: "32319F0E-9154-41CA-A081-F882DB18171D")!: Coord2D(30, 218),
        UUID(uuidString: "1B870A34-5AB0-463B-B349-6FF66184403A")!: Coord2D(30, 126),
        UUID(uuidString: "44431ACE-F21E-4797-95B0-A0824830BAD7")!: Coord2D(170, 25),
        UUID(uuidString: "DE8AD5B4-F6EC-4E4D-A665-944308173638")!: Coord2D(30, 25),
        UUID(uuidString: "CCD6CF0C-E5EC-438A-BFE8-8D8F0544EE49")!: Coord2D(320, 25),
        UUID(uuidString: "B719F6D4-1B04-49C7-9106-DE1CB2AE0A76")!: Coord2D(320, 180),
        UUID(uuidString: "E8178AD8-D91A-4685-B3A2-8043A9A91148")!: Coord2D(320, 338),
        UUID(uuidString: "018FB050-C899-4D28-9870-07DF953269CA")!: Coord2D(30, 400),
        UUID(uuidString: "30B1B1E2-BBB5-48DB-8268-27587C776B8B")!: Coord2D(170, 180),
        UUID(uuidString: "86095733-67FA-4398-BD93-9C33D02228CE")!: Coord2D(30, 309)]
)

PlaygroundPage.current.setLiveView(pad.frame(width: 500, height: 500))
