
public struct Coord2D: Hashable, InitialiserPrintable {
    public typealias FloatingPoint = Double
    var x: FloatingPoint
    var y: FloatingPoint
    
    public init(_ x: FloatingPoint, _ y: FloatingPoint) {
        self.x = x
        self.y = y
    }
    
    var initString: String {
        "Coord2D(\(self.x), \(self.y))"
    }
    
    public static func +(lhs: Self, rhs: Self) -> Self {
        Coord2D(lhs.x + rhs.x, lhs.y + rhs.y)
    }
}

public struct Coord2Dx2: Hashable {
    let p1: Coord2D
    let p2: Coord2D
    
    public init(_ p1: Coord2D, _ p2: Coord2D) {
        self.p1 = p1
        self.p2 = p2
    }
}
