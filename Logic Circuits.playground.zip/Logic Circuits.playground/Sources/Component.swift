import SwiftUI

public struct Component: Identifiable {
    public let id: UUID
    var state: Bool
    var outputs: [Set<GateXput>]
    var name: String?
    
    var connectable: Bool
    
    let configuration: CConfig
    
    public init(id: UUID = .init(), name: String? = nil, state: Bool = false, outputs: [Set<GateXput>] = [], _ configuration: CConfig, connectable: Bool = true) {
        self.state = state
        self.id = id
        self.name = name
        self.outputs = outputs + .init(repeating: [], count: configuration.outputs - outputs.count)
        self.configuration = configuration
        self.connectable = connectable
    }
    
    public struct CConfig: InitialiserPrintable, Equatable, Hashable {
        
        let logic: GateLogic.AnyGate
        let name: String
        let id: String
        let inputs: Int
        let outputs: Int
        let fixed: Bool
        let path: AnyView
        
        public init(logic: @escaping GateLogic.AnyGate, name: String, id: String, inputs: Int, outputs: Int = 1, fixed: Bool = false, path: AnyView) {
            self.logic = logic
            self.name = name
            self.id = id
            self.inputs = inputs
            self.outputs = outputs
            self.fixed = fixed
            self.path = path
        }
        
        public static let not  = Self.init(logic: GateLogic.NOT, name: "Not", id: "not", inputs: 1, path: NOT_PATH.anyView)
        public static let and2 = Self.init(logic: GateLogic.AND_2, name: "And (2)", id: "and2", inputs: 2, path: AND_PATH.anyView)
        public static let and3 = Self.init(logic: GateLogic.AND_3, name: "And (3)", id: "and3", inputs: 3, path: AND_PATH.anyView)
        public static let or2  = Self.init(logic: GateLogic.OR_2, name: "Or (2)", id: "or2", inputs: 2, path: OR_PATH.anyView)
        public static let or3  = Self.init(logic: GateLogic.OR_3, name: "Or (3)", id: "or3", inputs: 3, path: OR_PATH.anyView)
        public static let xor2 = Self.init(logic: GateLogic.XOR_2, name: "Xor", id: "xor2", inputs: 2, path: XOR_PATH.anyView)
        
        public static let input  = Self.init(logic: GateLogic.PASS, name: "Fixed Input", id: "input", inputs: 0,  outputs: 1, fixed: true, path: FI_SHAPE.anyView)
        public static let output = Self.init(logic: GateLogic.PASS, name: "Fixed Output", id: "output", inputs: 1, outputs: 0, fixed: true, path: FO_SHAPE.anyView)
        
        public static func ==(lhs: Self, rhs: Self) -> Bool {
            lhs.initString == rhs.initString
        }
        
        public func hash(into hasher: inout Hasher) {
            hasher.combine(initString)
        }
        
        public var initString: String {
            return "Component.CConfig." + self.id
        }
        
    }
}

extension Component: InitialiserPrintable {
    public var initString: String {
        let oStr = outputs.map { $0.map (\.initString).unquoted() }.unquoted()
        return "Component(id: \(self.id.initString), name: \(self.name?.quoted() ?? "nil"), state: \(self.state), outputs: \(oStr), \(self.configuration.initString), connectable: \(self.connectable))"
    }
}

public enum GateLogic {
    
    public typealias AnyGate = (Bool, Bool, Bool) -> Bool
    
    public static let PASS:  AnyGate = { b1, _, _ in  b1 }
    public static let NOT:   AnyGate = { b1, _, _ in !b1 }
    public static let AND_2: AnyGate = { b1, b2, _ in b1 && b2 }
    public static let AND_3: AnyGate = { $0 && $1 && $2 }
    public static let OR_2:  AnyGate = { b1, b2, _ in b1 || b2 }
    public static let OR_3:  AnyGate = { $0 || $1 || $2 }
    public static let XOR_2: AnyGate = { b1, b2, _ in (b1 || b2) && !(b1 && b2) }
    
}

public struct GateXput: Hashable, InitialiserPrintable {
    
    let id: UUID
    let node: Int
    
    public init(id: UUID, node: Int) {
        self.id = id
        self.node = node
    }
    
    var initString: String {
        "GateXput(id: \(id.initString), node: \(node))"
    }
}
