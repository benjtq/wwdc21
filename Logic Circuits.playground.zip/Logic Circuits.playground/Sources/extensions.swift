import SwiftUI

protocol InitialiserPrintable {
    var initString: String { get }
}

// MARK: - Color
public extension Color {
    
    init(red: UInt8, green: UInt8, blue: UInt8) {
        self.init(red: Double(red) / 255.0, green: Double(green) / 255.0, blue: Double(blue) / 255.0)
    }
    
    static let neuGrey: Color = Color(red: 200, green: 200, blue: 200)
    static let neuDarkShadow = Color(red: 190, green: 190, blue: 190)
    static let neuLightShadow = Color.white
    static let neuForeground = Color(red: 230, green: 230, blue: 230)
    
    static let fixedPowered = Color(#colorLiteral(red: 0.6849261412, green: 0.2576871199, blue: 0.1491478981, alpha: 1))
    static let powered = Color(#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1))
}

// MARK: - View
// Neumorphic theme
public extension View {
    func neuShadow() -> some View {
        self.shadow(color: .neuDarkShadow, radius: 15, x: NEU_SHADOW_DISTANCE, y: NEU_SHADOW_DISTANCE)
            .shadow(color: .neuLightShadow, radius: 15, x: -NEU_SHADOW_DISTANCE, y: -NEU_SHADOW_DISTANCE)
    }
    
    func neuCorners() -> some View {
        self.cornerRadius(17)
    }
    
    func neuRecessed(cornerRadius: CGFloat) -> some View {
        
        self
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(Color.neuDarkShadow, lineWidth: 4)
                    .blur(radius: 4)
                    .offset(x: 2, y: 2)
                    .mask(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).fill(LinearGradient(gradient: Gradient(colors: [Color.black, Color.clear]), startPoint: .leading, endPoint: .trailing)))
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(Color.neuLightShadow, lineWidth: 4)
                    .blur(radius: 5)
                    .offset(x: -2, y: -2)
                    .mask(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).fill(LinearGradient(gradient: Gradient(colors: [Color.clear, Color.black]), startPoint: .leading, endPoint: .trailing)))
            )
    }
    
    var anyView: AnyView { AnyView(self) }
}

public let NEU_SHADOW_DISTANCE: CGFloat = 10

// MARK: - Collection
extension Collection {
    func find<Identifier: Equatable>(_ value: Identifier, by keyPath: KeyPath<Element, Identifier>) -> Element? {
        guard let index = self.firstIndex(where: { $0[keyPath: keyPath] == value }) else { return nil }
        return self[index]
    }
}

extension Array where Element: Identifiable {
    func firstIndex(of element: Element) -> Index? {
        self.enumerated().filter {
            Element.isEqual($0.element, element)
        }.first?.offset
    }
    
    mutating func remove(_ item: Element) {
        self.remove(at: self.firstIndex(of: item)!)
    }
}

public extension Array where Element == Component.CConfig {
    static let all: Self = [.not, .and2, .and3, .or2, .or3, .xor2]
    static let allAndFixed: Self = .all + [.input, .output]
}

public extension Identifiable {
    static func isEqual(_ lhs: Self, _ rhs: Self) -> Bool {
        lhs.id == rhs.id
    }
}

extension UUID {
    var initString: String {
        "UUID(uuidString: \"" + self.uuidString + "\")!"
    }
}

extension Array where Element == String {
    func unquoted(newline: Bool = false) -> String {
        "[" + self.joined(separator: ", \(newline ? "\n" : "")") + "]"
    }
}

public extension String {
    func quoted() -> String {
        "\"\(self)\""
    }
}

// MARK: - NSTextField
public extension NSTextField {
    override var focusRingType: NSFocusRingType {
        get { .none }
        set { }
    }
}
