import SwiftUI

public struct ComponentBar: View {
    
    static let HEIGHT: CGFloat = 100
    
    @Binding var components: [Component.CConfig]
    let addGate: (Component, Coord2D) -> Void
    
    @State var hover: Component.CConfig? = nil
    
    func newGate_v(config: Component.CConfig, maxWidth: CGFloat) -> some View {
        VStack(alignment: .center) {
            config.path
                .foregroundColor(Color.neuGrey)
                .frame(width: Pad.PATH_WIDTH, height: Pad.PATH_HEIGHT)
            
            Text(config.name)
                .font(.system(size: 14, weight: .bold, design: .default))
                .foregroundColor(.neuGrey)
                .multilineTextAlignment(.center)
        }
    }
    
    public var body: some View {
        GeometryReader { container in
            HStack(spacing: 0) {
                ForEach(components, id: \.self) { c in
                    ZStack {
                        
                        Button(action: { withAnimation { addGate(Component(c), Coord2D(Double(container.frame(in: .global).width) / 2 - Double(Pad.GATE_WIDTH) / 2, 150)) } }) {
                            Color.neuGrey
                                .onHover { hover = $0 ? c : nil }
                                .neuRecessed(cornerRadius: 17)
                                .frame(width: container.frame(in: .global).width / CGFloat(components.count))
                                .opacity(hover == c ? 0.25 : 0.01)
                        }
                        .buttonStyle(PlainButtonStyle())
                        newGate_v(config: c, maxWidth: container.frame(in: .global).width / CGFloat(components.count))
                            .padding(.horizontal)
                            .frame(width: container.frame(in: .global).width / CGFloat(components.count))
                            .allowsHitTesting(false)
                    }
                }
            }
        }
        
        .neuRecessed(cornerRadius: 17)
        .neuCorners()
        .padding()
    }
}
