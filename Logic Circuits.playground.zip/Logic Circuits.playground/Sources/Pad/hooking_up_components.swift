import SwiftUI

extension Pad {
    func connectionLogic(selectedOutput: GateXput?, selectedInput: GateXput?) {
        guard let out = selectedOutput, let in_ = selectedInput else {
            // Set state shxt
            // Actually no
            return
        }
        
        let goesToFixedOut = layout.find(in_.id, by: \.id)!.configuration == .output
        let isExclusiveInput = inputsForNode(in_).isEmpty
        let isExclusiveInputToGate = !goesToFixedOut && isExclusiveInput
        
        // Connect two gates
        
        var testLayout = layout
        testLayout[testLayout.firstIndex { $0.id == out.id }!].outputs[out.node].insert(in_)
        
        if !Self.isRecursiveLayout(testLayout, at: in_.id) && (isExclusiveInputToGate || goesToFixedOut) {
            let lineInIndex = layout.firstIndex { $0.id == out.id }!
            let lineOutNodes = layout.first { $0.id == in_.id }!.configuration.inputs
            
            layout[lineInIndex].outputs[out.node].insert(in_)
            connectorLines.insert(ConnectorLine(in: out, out: in_, inNodes: layout[lineInIndex].configuration.outputs, outNodes: lineOutNodes))
        }
        
        resetTemporarySelection()
        reevaluateLogic()
    }
    
    static func isRecursiveLayout(_ layout: [Component], at startID: UUID) -> Bool {
        var accumulator: [UUID] = []
        
        func outputs(of cID: UUID) {
            let immediateOutputs = layout.first { $0.id == cID }!.outputs.flatMap { $0.map(\.id) }
            accumulator += immediateOutputs
            
            if accumulator.contains(startID) { return }
            immediateOutputs.forEach { outputs(of: $0) }
        }
        
        outputs(of: startID)
        return accumulator.contains(startID)
    }
}
