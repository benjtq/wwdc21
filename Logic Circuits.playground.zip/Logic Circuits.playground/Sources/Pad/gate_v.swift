import SwiftUI

extension Pad {
    static let GATE_WIDTH: CGFloat = 100
    static let GATE_HEIGHT: CGFloat = 75
    static let PATH_WIDTH: CGFloat = 30
    static let PATH_HEIGHT: CGFloat = GATE_HEIGHT * 0.5
    
    func comp_path_v(component: Component) -> some View {
        component.configuration.path
    }
    
    func component_v(_ component: Component) -> some View {
        
        guard !component.configuration.fixed else {
            return ZStack(alignment: .bottom) {
                Pad.connDot_v(size: Pad.FI_CONN_DOT_SIZE, isOutput: nil)
                    .foregroundColor(component.state ? .fixedPowered : .neuGrey)
                TextField("Label", text: Binding(get: { component.name ?? "" }, set: { layout[layout.firstIndex(of: component)!].name = $0 }) )
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(.neuGrey)
                    .font(.system(size: 14, weight: .heavy))
                    .multilineTextAlignment(.center)
                    .offset(y: 25)
            }
            
        }
        
        return ZStack(alignment: .center) {
            ZStack {
                Color.neuForeground
                
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .foregroundColor(.white)
                    .blur(radius: 4)
                    .offset(x: -8, y: -8)
                
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        LinearGradient(gradient: Gradient(colors: [Color.neuForeground, Color.neuLightShadow]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .padding(2)
                    .blur(radius: 2)
            }
            
            .neuCorners()
            .frame(width: Self.GATE_WIDTH, height: Self.GATE_HEIGHT)
            .neuShadow()
            
            ZStack {
                comp_path_v(component: component).foregroundColor(Color.neuGrey)
                component.configuration.path.foregroundColor(Color.neuLightShadow).offset(x: 2, y: 2).blur(radius: 1).mask(comp_path_v(component: component)).opacity(0.5)
            }
            .frame(width: Self.PATH_WIDTH, height: Self.PATH_HEIGHT)
        }
    }
}
