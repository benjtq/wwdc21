import SwiftUI

public struct Pad: View {
    
    @State var gates:  [Component.CConfig]
    @State var layout:  [Component]
    @State var connectorLines: Set<ConnectorLine>
    
    @State var preGesturePositions: [UUID : Coord2D]
    @State var positions:           [UUID : Coord2D]
    
    @State var temp_selectedInput:  GateXput? = nil
    @State var temp_selectedOutput: GateXput? = nil
    
    @State var isDragging = false
    
    func resetTemporarySelection() {
        temp_selectedInput = nil
        temp_selectedOutput = nil
    }
    
    static let INSET: Double = 25
    
    ///
    /// - parameter layout: Gate objects are copied, do not treat as reference types
    public init(gates: [Component.CConfig], layout: [Component], positions: [UUID : Coord2D]) {
        
        self._gates = .init(wrappedValue: gates)
        self._layout = .init(wrappedValue: layout)
        self._positions = .init(wrappedValue: positions)
        self._preGesturePositions = .init(wrappedValue: positions)
        self._connectorLines = .init(wrappedValue: Self.getConnectorLines(forLayout: layout))
        
        reevaluateLogic()
        
    }
    
    // MARK: - Gate drag gesture
    private func dragGesture(cID: UUID, bounds: CGSize) -> some Gesture {
        DragGesture(coordinateSpace: .global).onChanged { value in
            
            isDragging = true
            
            let newX = max(min(self.preGesturePositions[cID]!.x + Double(value.translation.width), Double(bounds.width - Pad.GATE_WIDTH) - Self.INSET), Self.INSET)
            let newY = max(min(self.preGesturePositions[cID]!.y - Double(value.translation.height), Double(bounds.height - Pad.GATE_HEIGHT) - Self.INSET), Self.INSET)
            
            let sd = NEU_SHADOW_DISTANCE * 1.5
            
            var excluding = positions
            excluding[cID] = nil
            
            guard excluding.map({ _, pos in
                (Double(-Pad.GATE_WIDTH - sd) ... Double(Pad.GATE_WIDTH + sd)).contains(pos.x - newX) &&
                        (Double(-Pad.GATE_HEIGHT - sd) ... Double(Pad.GATE_HEIGHT + sd)).contains(pos.y - newY)
            }).contains(true) else {
            
                self.positions[cID]!.x = newX
                self.positions[cID]!.y = newY
                
                return 
            }
        }.onEnded { _ in
            self.preGesturePositions[cID] = self.positions[cID]
            isDragging = false
        }
    }
    
    func toggleState(cID: UUID) {
        let index = layout.firstIndex { $0.id == cID }!
        withAnimation {
            layout[index].state.toggle()
        }
        reevaluateLogic()
    }
    
    // MARK: - body
    public var body: some View {
        GeometryReader { container in
            ZStack(alignment: .topLeading) {
                Color.neuForeground.cornerRadius(23)
                ComponentBar(components: self.$gates, addGate: self.add)
                    .frame(width: container.size.width, height: 120, alignment: .bottom)
                    .opacity(self.gates.isEmpty ? 0.0 : 1.0)
                
                ForEach(layout) { component in
                    ZStack {
                        component_v(component)
                            .onTapGesture(count: 2) {
                                if component.configuration == .input { toggleState(cID: component.id) }
                            }
                            .onLongPressGesture { remove(cID: component.id) }
                        if component.connectable { connDots(component: component).zIndex(1) }
                    }
                    .frame(width: Self.GATE_WIDTH, height: Self.GATE_HEIGHT)
                    .offset(x: CGFloat(positions[component.id]!.x), y: CGFloat(positions[component.id]!.y))
                    .animation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0))
                    .gesture(dragGesture(cID: component.id, bounds: container.size))

                }
                .frame(maxHeight: .infinity, alignment: .topLeading)
                .zIndex(isDragging ? 1 : 0)
                connectorLines_v.opacity(isDragging ? 0.5 : 0.5)
                Button { print(initString) } label: { Text("Print") }.frame(alignment: .bottomTrailing).padding()
            }
            .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(Color.neuGrey, lineWidth: 10).frame(width: container.size.width - 10, height: container.size.height - 10))
            .frame(maxWidth: .infinity, maxHeight: .infinity)


        }
    }
    
    func add(component: Component, position: Coord2D) {
        layout.append(component)
        positions[component.id] = position
        preGesturePositions[component.id] = position
    }

    func remove(cID: UUID) {
        var ins: [GateXput] = []
        
        (0 ..< layout.count).forEach { component in
            (0 ..< layout[component].outputs.count).forEach { node in
                layout[component].outputs[node] = layout[component].outputs[node].filter {
                    guard $0.id == cID else { return true }
                    ins.append(GateXput(id: layout[component].id, node: node))
                    return false
                }
            }
        }
        
        withAnimation { connectorLines = connectorLines.filter { $0.out.id != cID && $0.in_.id != cID } }
        withAnimation { layout.remove(layout.find(cID, by: \.id)!) }
        positions[cID] = nil
        preGesturePositions[cID] = nil
        
        reevaluateLogic()
    }
    
    static func getConnectorLines(forLayout layout: [Component]) -> Set<ConnectorLine> {
        let lines: [ConnectorLine] = layout.flatMap { c in
            Array(c.outputs.enumerated().flatMap { nodeOuts in

                nodeOuts.element.map { xput in
                    return ConnectorLine(in: GateXput(id: c.id, node: nodeOuts.offset), out: xput, inNodes: c.configuration.outputs, outNodes: layout.find(xput.id, by: \.id)!.configuration.inputs)
                }
            })
        }

        return Set(lines)
    }
}

extension Pad: InitialiserPrintable {
    var initString: String {
"""
Pad(
    gates: \(gates.map(\.initString).unquoted()),
    layout: \(layout.map(\.initString).unquoted(newline: true)),
    positions: \(positions.initString)
)
"""
    }
}

extension Dictionary: InitialiserPrintable where Key == UUID, Value == Coord2D {
    var initString: String {
        self.map { id, pos in
            "\(id.initString): \(pos.initString)"
        }.unquoted(newline: true)
    }
}
