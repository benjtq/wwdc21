import SwiftUI

extension Pad {
    
    func inputsDidChange(cID: UUID) {
        let index = layout.firstIndex { $0.id == cID }!
        
        var inputs = inputStates(cID: cID)
        
        inputs += [Bool](repeating: false, count: 3 - inputs.count)
        
        withAnimation {
            layout[index].state = layout[index].configuration.logic(inputs[0], inputs[1], inputs[2])
        }
        layout[index].outputs.forEach { node in node.forEach { inputsDidChange(cID: $0.id) } }
    }
    
    func inputStates(cID: UUID) -> [Bool] {
        layout.filter { gate in gate.outputs.contains { node in node.contains { $0.id == cID } } }.map { $0.state }
    }
    
    /// Gate outputs which connect into a node of the gate
    func inputComponentIDs(cID: UUID) -> [UUID] {
        layout.filter { gate in gate.outputs.contains { node in node.contains { $0.id == cID } } }.map { $0.id }
    }
    
    func inputsForNode(_ xput: GateXput) -> [UUID] {
        layout.filter { c in
            c.outputs.contains { $0.contains(xput) }
        }.map(\.id)
    }
    
    func reevaluateLogic() {
        
        /// This lovely bit of code finds stranded gates with no inputs, and sets their states to false
        /// This also doesn't give the stranded gates any chance to perform logic.
        layout
            .filter { $0.configuration != Component.CConfig.input && inputStates(cID: $0.id).isEmpty } // gates that ar emty
            .forEach { component in
                layout[layout.firstIndex(of: component)!].state = false
        }
        
        /// Because, this bit of code below which updates gate states, works by finding them by their inputs.
        layout
            .filter { $0.configuration == Component.CConfig.input } // fixed input gates
            .flatMap { $0.outputs.flatMap { node in node.map(\.id) } }
            .forEach { firstGate in
                inputsDidChange(cID: firstGate)
        }
        
        // Update fixed output state
        layout
            .filter { $0.configuration == Component.CConfig.output } // fixed output gates
            .forEach { output in // fixed outputs are basically, or gates
                let state = inputStates(cID: output.id).contains(true)
                layout[layout.firstIndex(of: output)!].state = state
            }
        
    }
    
}
