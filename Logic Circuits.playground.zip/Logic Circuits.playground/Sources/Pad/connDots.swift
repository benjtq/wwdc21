import SwiftUI

extension Pad {
    
    static let CONN_DOT_SIZE: CGFloat = 16
    static let FI_CONN_DOT_SIZE: CGFloat = CONN_DOT_SIZE * 1.9
    
    static let CONN_DOT_INSET_X: CGFloat = 10
    
    private static func localCoordsForNode_Input(_ input: GateXput, nodes: Int) -> Coord2D {
        let x = CONN_DOT_INSET_X + CONN_DOT_SIZE / 2
        let y = ((Pad.GATE_HEIGHT - (CGFloat(nodes) * Self.CONN_DOT_SIZE)) / CGFloat(nodes + 1)) * CGFloat(input.node + 1) + Self.CONN_DOT_SIZE * CGFloat(input.node) + (Self.CONN_DOT_SIZE / 2)
        return Coord2D(Double(x), Double(y))
    }
    
    func coordsForNode(xput: GateXput, maxNodes nodes: Int, in isInput: Bool) -> Coord2D {
        
        let cpos = positions[xput.id]!
        
        let asInput = Self.localCoordsForNode_Input(xput, nodes: nodes)
        
        guard isInput else {
            return cpos + Coord2D(Double(Pad.GATE_WIDTH) - asInput.x, asInput.y)
        }
        
        return cpos + asInput
    }
    
    // MARK: - connDot_v
    static func connDot_v(size: CGFloat = Self.CONN_DOT_SIZE, shadows: Bool = true, isOutput: Bool?) -> some View {
        
        let v: AnyView
        
        if let isOutput = isOutput {
            v = isOutput ? Circle().anyView : Triangle().anyView
        } else {
            v = Circle().stroke(lineWidth: size * 0.2).overlay(Circle().frame(width: size * 0.4))
                .background(Color.white.opacity(0.01))
                .anyView
        }
        
        guard !shadows else { return v.neuShadow().frame(width: size, height: size, alignment: .center).anyView }
        return v.frame(width: size, height: size, alignment: .center).anyView
    }
    
    
    func connDots(component: Component) -> some View {
        let inputs_c  = component.configuration.inputs
        let outputs_c = component.configuration.outputs
        
        let inputNodeStates: [Bool] = (0 ..< inputs_c).map { node in
            layout.first { icomp in
                icomp.outputs.contains { $0.contains(GateXput(id: component.id, node: node)) }
            }?.state ?? false
        }
        
        return HStack {
            
            // MARK: Gate input nodes
            VStack(spacing: 0) {
                ForEach(0 ..< inputs_c) { input in
                    Pad.connDot_v(isOutput: false)
                        .foregroundColor(inputNodeStates[input] ? .powered : .neuGrey)
                        .onTapGesture {
                            temp_selectedInput = GateXput(id: component.id, node: input)
                            connectionLogic(selectedOutput: temp_selectedOutput, selectedInput: temp_selectedInput)
                        }
                }
                .frame(height: (Pad.GATE_HEIGHT - (CGFloat(inputs_c) * Self.CONN_DOT_SIZE)) / CGFloat(inputs_c + 1) + Self.CONN_DOT_SIZE, alignment: .bottom)
            }.frame(height: Pad.GATE_HEIGHT, alignment: .top)
            
            Spacer()
            
            // MARK: Gate output nodes
            VStack(spacing: 0) {
                ForEach(0 ..< outputs_c) { output in
                    Pad.connDot_v(isOutput: true)
                        .foregroundColor(component.state ? .powered : .neuGrey)
                        .onTapGesture {
                            temp_selectedOutput = GateXput(id: component.id, node: output)
                            connectionLogic(selectedOutput: temp_selectedOutput, selectedInput: temp_selectedInput)
                        }
                }
                .frame(height: (Pad.GATE_HEIGHT - (CGFloat(outputs_c) * Self.CONN_DOT_SIZE)) / CGFloat(outputs_c + 1) + Self.CONN_DOT_SIZE, alignment: .bottom)
            }.frame(height: Pad.GATE_HEIGHT, alignment: .top)
            
        }.padding(.horizontal, Self.CONN_DOT_INSET_X).frame(width: Pad.GATE_WIDTH, height: Pad.GATE_HEIGHT)
    }
    
}

struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        Path {
            let maxX = rect.width
            let maxY = rect.height
            
            $0.move(to: CGPoint(x: maxX / 2, y: 0))
            $0.addLine(to: CGPoint(x: maxX, y: maxY))
            $0.addLine(to: CGPoint(x: 0, y: maxX))
            $0.addLine(to: CGPoint(x: maxX / 2, y: 0))
        }
    }
}
