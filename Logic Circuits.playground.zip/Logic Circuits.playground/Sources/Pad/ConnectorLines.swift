import SwiftUI

public struct ConnectorLine: Identifiable, Hashable {
    
    public let id = UUID()
    
    /// ID of the component **connected to the start of this connection line**
    let in_: GateXput
    /// ID of the component **connected to the end of this connection line**
    let out: GateXput
    
    let inNodeCount: Int
    let outNodeCount: Int
    
    var coords: Coord2Dx2? = nil
    
    public init(in in_: GateXput, out: GateXput, inNodes: Int, outNodes: Int) {
        self.in_ = in_
        self.out = out
        self.inNodeCount = inNodes
        self.outNodeCount = outNodes
    }
}

extension Pad {
    func connectorLine(in in_: Coord2D, out: Coord2D, state: Bool) -> some View {
        
        Path {
            $0.move(to: CGPoint(x: in_.x, y: in_.y))
            $0.addLine(to: CGPoint(x: out.x, y: out.y))
        }
            .strokedPath(StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
        .fill(state ? Color.powered : Color.neuGrey)
    }
    
    var connectorLines_v: some View {
        let lines = connectorLines.map { cl -> ConnectorLine in
            
            let in_ = coordsForNode(xput: cl.in_, maxNodes: cl.inNodeCount, in: false)
            let out = coordsForNode(xput: cl.out, maxNodes: cl.outNodeCount, in: true)
            
            var cl = cl; cl.coords = Coord2Dx2(in_, out);
            return cl
        }
        
        return ForEach(lines, id: \.self) { cl in
            let state = layout.find(cl.in_.id, by: \.id)!.state
            
            connectorLine(in: cl.coords!.p1, out: cl.coords!.p2, state: state)
                .onLongPressGesture {
                    
                    let _ = withAnimation { connectorLines.remove(connectorLines.find(cl.id, by: \.id)!) }
                    
                    let inGate = layout.firstIndex { $0.id == cl.in_.id }!
                    layout[inGate].outputs[cl.in_.node].remove(cl.out)
                    
                    reevaluateLogic()
                
                }
        }
    }
}

