import SwiftUI

let AND_PATH = Path {
    let maxX = Pad.PATH_WIDTH
    let maxY = Pad.PATH_HEIGHT
    
    $0.addArc(center: CGPoint(x: maxX / 2, y: maxY / 2), radius: maxY / 2, startAngle: .degrees(90), endAngle: .degrees(270), clockwise: true)
    
    $0.move(to: .zero)
    $0.addLine(to: CGPoint(x: maxX / 2.1, y: 0))
    
    $0.move(to: CGPoint(x: maxY / 2.1, y: maxY))
    $0.addLine(to: CGPoint(x: 0, y: maxY))
    
    $0.addLine(to: .zero)
    
    
}.strokedPath(StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))

let OR_PATH = Path {
    let maxX = Pad.PATH_WIDTH
    let maxY = Pad.PATH_HEIGHT
    
    $0.move(to: .zero)
    
    $0.addQuadCurve(to: CGPoint(x: maxX, y: maxY / 2), control: CGPoint(x: maxX, y: 0))
    $0.addQuadCurve(to: CGPoint(x: 0, y: maxY), control: CGPoint(x: maxX, y: maxY))
    
    $0.addQuadCurve(to: .zero, control: CGPoint(x: maxX / 2, y: maxY / 2))
}.strokedPath(StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))

let XOR_PATH = Path {
    let maxX = Pad.PATH_WIDTH
    let maxY = Pad.PATH_HEIGHT
    
    let lineInset: CGFloat = 7.5
    
    $0.move(to: CGPoint(x: lineInset, y: 0))
    
    $0.addQuadCurve(to: CGPoint(x: maxX, y: maxY / 2), control: CGPoint(x: maxX, y: 0))
    $0.addQuadCurve(to: CGPoint(x: lineInset, y: maxY), control: CGPoint(x: maxX, y: maxY))
    
    $0.addQuadCurve(to: CGPoint(x: lineInset, y: 0), control: CGPoint(x: maxX / 2 + lineInset, y: maxY / 2))
    $0.move(to: CGPoint(x: 0, y: maxY))
    $0.addQuadCurve(to: .zero, control: CGPoint(x: maxX / 2, y: maxY / 2))
}.strokedPath(StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))

let NOT_PATH = Path {
    let maxX = Pad.PATH_WIDTH
    let maxY = Pad.PATH_HEIGHT
    
    $0.move(to: .zero)
    
    $0.addLine(to: CGPoint(x: maxX, y: maxY / 2))
    $0.addLine(to: CGPoint(x: 0, y: maxY))
    $0.addLine(to: .zero)
    
    $0.move(to: CGPoint(x: maxX, y: 0))
    $0.addLine(to: CGPoint(x: maxX, y: maxY))
}.strokedPath(StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))

var FI_SHAPE: some View { Pad.connDot_v(size: Pad.FI_CONN_DOT_SIZE, shadows: false, isOutput: true) }
var FO_SHAPE: some View { Pad.connDot_v(size: Pad.FI_CONN_DOT_SIZE, shadows: false, isOutput: false) }
